# WAVR 🎵 — Spotify Clone

A sleek music streaming app powered by YouTube Music.

## Setup

### 1. Install system dependencies

**macOS:**
```bash
brew install python3 ffmpeg yt-dlp
```

**Windows:**
```bash
# Install Python from python.org
# Install ffmpeg from ffmpeg.org (add to PATH)
pip install yt-dlp
```

**Linux:**
```bash
sudo apt install python3 ffmpeg
pip install yt-dlp
```

---

### 2. Install Python packages

```bash
cd spotify-clone
pip install -r requirements.txt
```

---

### 3. Run the server

```bash
python server.py
```

Then open **http://localhost:5000** in your browser.

---

## Project Structure

```
spotify-clone/
├── server.py          ← Flask backend (search + stream)
├── requirements.txt   ← Python dependencies
└── frontend/
    ├── index.html     ← App shell
    ├── style.css      ← Styling
    └── app.js         ← All frontend logic
```

## Features

- 🔍 Search YouTube Music catalog
- 🎵 Stream audio directly (no files saved)
- ⏭ Queue management
- 🔀 Shuffle & repeat
- ♥ Like tracks (saved locally)
- 📋 Create playlists (saved locally)
- 📝 View lyrics
- ⌨️ Keyboard shortcuts (Space, Arrow keys)
- 🎮 Media key support

## Keyboard Shortcuts

| Key | Action |
|-----|--------|
| Space | Play / Pause |
| → | Seek +5s |
| ← | Seek -5s |
| ↑ | Volume up |
| ↓ | Volume down |

## Deploy to Render (free)

1. Push to GitHub
2. Go to render.com → New Web Service
3. Connect repo, set build command: `pip install -r requirements.txt`
4. Set start command: `python server.py`
5. Done ✅
